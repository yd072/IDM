# reset-idm-trial
重置IDM试用


reset.reg   修改注册表 重置试用

idm_keygen.py  生成序列号(需要python3，提醒，这个序列号已经无法正常激活IDM，仅供学习使用)
